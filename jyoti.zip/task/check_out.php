<?php 
require('conn.php');
if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $state = $_POST['state'];
  $sql = "INSERT INTO payment_details(name,email,state) VALUES('$name', '$email','$state')";
   if (mysqli_query($conn, $sql)) 
   {
        header("location:thanku.php");
    } 
    else 
    {
      echo "Error: " . mysqli_error($conn);
    }
}
?>
<html lang="en">
<head>
  <title>Check Out Box</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2? 
    family=Roboto+Slab:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

  <div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-sm-7">
          <div class="login-box">
          <div class="mb-4 text-center"> <h2> Check Out  </h2> </div>
            <form action="" method="POST">

              <div class="row">
                 <div class="col-sm-6 mb-4">
                   <input type="text" class="form-control" placeholder="Name" name="name">   
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6 mb-4">
                   <input type="email" class="form-control" placeholder="E-mail" name="email">   
                </div>
              </div>

              <div class="form-group">
              <select name="state" class="form-control" id="state_name">
              <option value="">Select</option>

              <?php 
              $sql = "SELECT * FROM state where id = '$id";
              $result = mysqli_query($conn,$sql);
              while($row=mysqli_fetch_assoc($result))
              {
                ?>
                  <option value="<?php echo $row['id']; ?>"><?php echo $row['state_name']; ?></option>
                <?php
              }
              ?>
              </select>
              </div>
              <button type="submit" name="submit" class="btn btn-success btn-block"> Pay Now <i class="fa fa-send"></i> </button>
            </form>
          </div>
        </div>
    </div>
  </div>
</body>
</html>