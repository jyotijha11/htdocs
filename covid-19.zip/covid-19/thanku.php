<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>THANKU FOR VISITING</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<style type="text/css">
	body
	{
		background-image: url('https://cloudfront-us-east-2.images.arcpublishing.com/reuters/VEKSCTM4ERJNFDZX7ZKNEJZP2A.jpg');
		background-repeat: no-repeat;
		background-size: cover;


	}
	</style>
</head>
<body>
<div class="bg text-center">
    <!--Div for Centered Text & Input-->
    <div class="centered">
        <center>
        <h1>
        <h1>Thank-you</h1>
        <p>We asked and you responded with heartfelt </p>
        <p>shout-outs to professors, colleagues, students, </p>
        <p>and friends who’ve helped make the dark days of this</p>
        <p>pandemic just a little bit brighter.</p>
      </h1>
       </center>
		</div>
</body>
</html>